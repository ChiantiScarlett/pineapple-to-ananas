# pineapple-to-ananas

This chrome extension changes all `pineapple` texts to `ananas`.
